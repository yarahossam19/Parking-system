package com.Garage_System.java;

 interface FirstComeFirstServed
{
    int  configration1(int w , int d , int id);
}
