package com.Garage_System.java;

public interface ParkOutForm
{
    public void display(int id,Garage G);

}
