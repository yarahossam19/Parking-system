package com.Garage_System.java;

public interface ParkForm
{
   public void display(Vehicle car, Garage G);
}
