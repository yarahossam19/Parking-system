package com.Garage_System.java;

public interface BestFit
{
    int  configration2(int w , int d, int id);
}
